# Animation Notes
- Splash: Fade In (300ms)
- Login: Slide Left (300ms)
- Home: Smart Animate (400ms)
- Product: Move In
- Cart: Dissolve
- Checkout: Smart Animate
- Order Success: Scale
