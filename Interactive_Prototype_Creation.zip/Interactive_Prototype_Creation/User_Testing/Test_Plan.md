Participants: 3
Tasks: Login, Browse, Add to Cart, Checkout