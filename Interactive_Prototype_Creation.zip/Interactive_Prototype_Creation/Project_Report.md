# Project Report

Objective: Build a clickable prototype from wireframes.

Flow:
Splash -> Login -> Home -> Product -> Cart -> Checkout -> Order Success
